package board.gui;

public enum Pages {
	BoardList , BoardWrite , BoardContent 
}
